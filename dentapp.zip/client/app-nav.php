<!--Navigation bar-->
  <nav class="navbar navbar-default navbar-static-top" role="navigation">
    <div class="container">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php">DENT<span>APP</span></a>
      </div>
      <div class="collapse navbar-collapse" id="myNavbar">
        <ul class="nav navbar-nav navbar-right">
          <li><a href="index.php">Home</a></li>
          <li><a href="calendar">View Slots</a></li>
          <li><a href="app-service.php">Services</a></li>
          <!--li><a href="messages.php">Message</a></li>
          <li><a href="profile.php">Profile</a></li-->
          <li class="btn-trial"><a href="logout.php?logout" onclick="return confirm('Are you sure you want to Logout?')">Logout</a></li>
        </ul>
      </div>
    </div>
  </nav>

