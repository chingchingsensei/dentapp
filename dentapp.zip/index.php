<?php
  
session_start();

include('header.php');
include('nav.php');
?>
  

  <!--Banner-->
  <div class="banner">
    <div class="bg-color">
      <div class="container">
        <div class="row">
          <div class="banner-text text-center">
            <div class="text-border">
              <h2 class="text-dec">DENTAL EXPERT <BR> WITHIN YOUR REACH</h2>
            </div>
            <div class="intro-para text-center quote">
              <p class="big-text"></p>
              <p class="small-text"></p>
              
            </div>
            
          </div>
        </div>
      </div>
    </div>
  </div>
  <!--/ Banner-->



<?php
include('footer.php'); 
?>  

