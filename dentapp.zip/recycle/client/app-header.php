 <?php
 session_start();   
if( !isset($_SESSION['username']) ) {
	header("Location: ../index.php");
	exit;
}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="icon" href="../img/logo.png">
	<title>Tibiao-Dental</title>

	 <link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
	 <link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	 <link rel="stylesheet" type="text/css" href="../css/font-awesome.min.css">
	 <link rel="stylesheet" type="text/css" href="../css/style.css">
	 <link rel="stylesheet" type="text/css" href="select2/select2.min.css">
	<script src="js/jquery-1.12.4.js"></script>
	<script src="js/jquery-ui.js"></script>
	

</head>