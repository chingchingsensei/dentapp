
<?php

	include('app-header.php');
	include('app-nav.php');
?>
<body><br>
<div class="page-wrapper p-t-30 p-b-100">
   <div class="wrapper wrapper--w680">
   	<h2>Add Appointment</h2>
      <div class="card card-4">
        	<div class="card-body"> 
		        <form method="POST" class="mc-trial">

				<div class="form-group">
		          <div class="controls">
		          	<label>Appointment Type</label>
		          	<div class="rs-select2 js-select-simple select--no-search">
                                    <select name="apptype">
                                        <option disabled="disabled" selected="selected">Choose Appointment</option>
                                        <option>New Appointment</option>
                                        <option>Recall Appointment</option>
                                    </select>
                         <div class="select-dropdown"></div>
                    </div>
                 </div>
             	</div>     

		        <div class="form-group">
		          <div class="controls">
		          	<label>Choose Date:</label>
		          	<input class="form-control" type="text" name="select_date" id="select_date">		  
		          </div>
		        </div>

		          	<div class="col-2">
                                <div class="input-group"> 
                                    <label>Choose Time</label>
                                    <div class="p-t-10">

                 <?php
								require('../admin/dbcon.php');

								$sql = $DB_con->prepare("SELECT * FROM sched");
								$sql->setFetchMode(PDO::FETCH_ASSOC);
								$sql->execute();


								if($sql->rowCount() != 0) {

								?>
								<table><tr>
								   
								 <?php     
								 while($row=$sql->fetch()) 
								 {
								 	
								 	echo  "<th><input type='radio' checked='checked' name='sched_time'> ".
								 			date("H:i", strtotime($row["sched_time"])).
								           "</th>";
								     
								 } 

								}
								else
								{
								     echo "don't exist records for list on the table";
								}

								?>
								</tr>
								</table>

                        </div>
                    				  
		        	</div>
		        </div>
		        
				<div class="form-group">
		          <p>
		            <button name="submit" type="submit" class="btn btn-block btn-submit">
		            Submit <i class="fa fa-arrow-right"></i></button>
		          </p>
		        </div>
				</form>
			</div>
		</div>
	</div>
</div>


<script type="text/javascript">
	$(function(){
		$("#select_date").datepicker({
			format: "mm/dd/yyyy",
			autoclose: true,
			todayHighlight: true,
			showOtherMonths: true,
			selectOtherMonths: true,
			changeMonth: true,
			changeYear: true,
			minDate: new Date()
		});
	});
</script>
 <script type="text/javascript">
    var unavailableDates = ["9-5-2019", "14-5-2019", "15-5-2019"];

    function unavailable(date) {
        dmy = date.getDate() + "-" + (date.getMonth() + 1) + "-" + date.getFullYear();
        if ($.inArray(dmy, unavailableDates) == -1) {
            return [true, ""];
        } else {
            return [false, "", "Unavailable"];
        }
    }

    $(function() {
        $("#select_date").datepicker({
            dateFormat: 'dd MM yy',
            beforeShowDay: unavailable
        });

    });
</script>
</body>
<script src="select2/select2.min.js"></script>
<script src="js/global.js"></script>
</html>

