
 <?php 

 include('header.php'); 
 header("refresh:2;url=../index.php" );

 ?>  

<body>
	<center><br>
		<h1>THANK YOU FOR SIGNING UP</h1>
	</center>
</body>

 <?php include('footer.php'); ?> 