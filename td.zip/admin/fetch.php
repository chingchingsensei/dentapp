<?php
if(!empty($_GET['q']))
{
include '../admin/dbcon.php';
$q=$_GET['q'];
$query="select * from events where dates like '%$q%' LIMIT 3";
$result=$DB_con->prepare($query);
$result->execute();
while($output = $result->fetch(PDO::FETCH_ASSOC))
 {
echo '<a>'.$output['dates'].'</a>';
}

}

?>