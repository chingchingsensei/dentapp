<!DOCTYPE html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="bootstrap/css/style.css" rel="stylesheet" media="screen">
<link href="bootstrap/css/bootstrap.min.css" rel="stylesheet" media="screen">
<link href="bootstrap/css/bootstrap-theme.min.css" rel="stylesheet" media="screen">
<script type="text/javascript" src="jquery-1.11.3-jquery.min.js"></script>
<link rel="icon" href="../img/logo.png">

	 <link rel="stylesheet" type="text/css" href="css/jquery-ui.css">
	 
	 <link rel="stylesheet" type="text/css" href="css/jquery-ui-timepicker-addon.css">
	 <link rel="stylesheet" type="text/css" href="css/jquery.timepicker.css">
	 <link rel="stylesheet" type="text/css" href="css/jquery.timepicker.min.css">
	

	<script src="js/jquery-1.12.4.js"></script>
	<script src="js/jquery-ui.js"></script>
	<script src="js/jquery-ui-timepicker-addon.js"></script>
<title>Tibiao-Dental</title>

</head>
<body>