<div class="container"> <!--
	<div class="alert alert-info">
    <strong></strong> <a href=""></a>!
	</div>

-->
</div>

	

</body>
</html>

<script src="bootstrap/js/bootstrap.min.js"></script>